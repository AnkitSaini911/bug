<?php
$a= $_POST["name"];
echo $a
?>
