<?php
$a= htmlentities($_POST["name"]);
echo $a
?>
