<?php
    $a=$_GET['page'];
    include($a); 
    echo "hello".$a;
?>
